import React from 'react';
import { Canvas } from '@react-three/fiber';
import { FloatingCrystal } from './3d/FloatingCrystal';
import { Environment, Float, Preload } from '@react-three/drei';

interface LoadingAnimationProps {
  className?: string;
  fullScreen?: boolean;
  message?: string;
}

export function LoadingAnimation({ 
  className = '', 
  fullScreen = false,
  message = 'Loading...'
}: LoadingAnimationProps) {
  const animation = (
    <div className={`relative ${className}`}>
      <div className="w-64 h-64">
        <Canvas
          camera={{ position: [0, 0, 5], fov: 45 }}
          dpr={[1, 2]}
          gl={{ 
            antialias: true,
            alpha: true,
            preserveDrawingBuffer: true
          }}
        >
          <color attach="background" args={['transparent']} />
          
          <ambientLight intensity={0.5} />
          <spotLight
            position={[10, 10, 10]}
            angle={0.15}
            penumbra={1}
            intensity={1}
          />
          
          <Float
            speed={1.5}
            rotationIntensity={0.5}
            floatIntensity={0.5}
          >
            <FloatingCrystal />
          </Float>
          
          <Environment preset="sunset" />
          <Preload all />
        </Canvas>
      </div>
      
      {/* Subtle glow effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-radial from-indigo-500/5 to-transparent animate-pulse" />
      </div>
    </div>
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 bg-transparent backdrop-blur-sm flex flex-col items-center justify-center z-50">
        <div className="bg-transparent p-8">
          {animation}
          <p className="text-center mt-4 text-indigo-300 animate-pulse font-medium">
            {message}
          </p>
        </div>
      </div>
    );
  }

  return animation;
}