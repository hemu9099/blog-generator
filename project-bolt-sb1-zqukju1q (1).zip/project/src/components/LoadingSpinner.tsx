import { LoadingAnimation } from './LoadingAnimation';

interface LoadingSpinnerProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  fullScreen?: boolean;
}

export function LoadingSpinner({ 
  className = '', 
  size = 'md',
  fullScreen = false 
}: LoadingSpinnerProps) {
  return (
    <LoadingAnimation className={className} fullScreen={fullScreen} />
  );
}