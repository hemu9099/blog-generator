import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh } from 'three';
import { MeshTransmissionMaterial } from '@react-three/drei';

export function InteractiveLoader() {
  const groupRef = useRef<THREE.Group>(null);
  const time = useRef(0);

  useFrame((state, delta) => {
    if (groupRef.current) {
      time.current += delta;

      // Smooth rotation animation
      groupRef.current.rotation.y += delta * 0.5;
      
      // Gentle floating motion
      groupRef.current.position.y = Math.sin(time.current) * 0.1;
      
      // Subtle breathing effect
      const scale = 1 + Math.sin(time.current * 2) * 0.05;
      groupRef.current.scale.setScalar(scale);
    }
  });

  return (
    <group ref={groupRef}>
      {/* Main ring */}
      <mesh>
        <torusGeometry args={[1, 0.2, 32, 100]} />
        <MeshTransmissionMaterial
          backside
          samples={4}
          thickness={0.5}
          roughness={0}
          color="#4f46e5"
          attenuationDistance={0.2}
          attenuationColor="#60a5fa"
          transmission={0.95}
          distortion={0.5}
          distortionScale={0.5}
          temporalDistortion={0.1}
          transparent={true}
          opacity={0.8}
        />
      </mesh>

      {/* Inner ring */}
      <mesh rotation-x={Math.PI / 2}>
        <torusGeometry args={[0.6, 0.1, 32, 100]} />
        <meshPhongMaterial
          color="#818cf8"
          emissive="#4f46e5"
          emissiveIntensity={0.5}
          transparent={true}
          opacity={0.7}
        />
      </mesh>

      {/* Energy orbs */}
      {[...Array(8)].map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 8) * Math.PI * 2) * 1,
            Math.sin((i / 8) * Math.PI * 2) * 1,
            0
          ]}
          scale={0.15}
        >
          <sphereGeometry args={[1, 16, 16]} />
          <meshPhongMaterial
            color="#60a5fa"
            emissive="#4f46e5"
            emissiveIntensity={1}
            transparent={true}
            opacity={0.8}
          />
        </mesh>
      ))}

      {/* Ambient lighting */}
      <pointLight position={[2, 2, 2]} intensity={0.5} color="#4f46e5" />
      <pointLight position={[-2, -2, -2]} intensity={0.5} color="#60a5fa" />
    </group>
  );
}