import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh, Vector3 } from 'three';
import * as THREE from 'three';
import { MeshTransmissionMaterial } from '@react-three/drei';

export function RunningPet() {
  const meshRef = useRef<Mesh>(null);
  const position = useRef(new Vector3(0, 0, 0));
  const direction = useRef(1);
  const time = useRef(0);

  useFrame((state, delta) => {
    if (meshRef.current) {
      time.current += delta;

      // Smooth running animation with easing
      position.current.x += direction.current * delta * 2;
      
      // Enhanced bounce effect with smoother motion
      position.current.y = Math.sin(time.current * 8) * 0.15;
      
      // Change direction at boundaries with smooth transition
      if (position.current.x > 2) {
        direction.current = -1;
        meshRef.current.scale.x = 1.2; // Squash effect on turn
      }
      if (position.current.x < -2) {
        direction.current = 1;
        meshRef.current.scale.x = 1.2; // Squash effect on turn
      }
      
      // Gradually return to normal scale
      meshRef.current.scale.x = THREE.MathUtils.lerp(
        meshRef.current.scale.x,
        1,
        delta * 5
      );
      
      // Update mesh position with smooth interpolation
      meshRef.current.position.lerp(position.current, 0.1);
      
      // Smooth rotation based on direction
      const targetRotation = direction.current > 0 ? Math.PI : 0;
      meshRef.current.rotation.y = THREE.MathUtils.lerp(
        meshRef.current.rotation.y,
        targetRotation,
        delta * 10
      );
      
      // Dynamic squash and stretch effect
      const runCycle = Math.sin(time.current * 15);
      meshRef.current.scale.y = 1 + runCycle * 0.1;
      meshRef.current.scale.z = 1 - runCycle * 0.05;
    }
  });

  return (
    <group>
      {/* Body */}
      <mesh ref={meshRef}>
        <group position={[0, 0.5, 0]}>
          {/* Main body */}
          <mesh position={[0, 0, 0]}>
            <sphereGeometry args={[0.8, 32, 32]} />
            <MeshTransmissionMaterial
              backside
              samples={4}
              thickness={0.5}
              roughness={0}
              color="#ff1d58"
              attenuationDistance={0.2}
              attenuationColor="#fff685"
              transmission={0.95}
              distortion={0.5}
              distortionScale={0.5}
              temporalDistortion={0.1}
            />
          </mesh>
          
          {/* Head */}
          <mesh position={[0.6, 0.3, 0]}>
            <sphereGeometry args={[0.4, 32, 32]} />
            <MeshTransmissionMaterial
              backside
              samples={4}
              thickness={0.5}
              roughness={0}
              color="#f75990"
              attenuationDistance={0.2}
              attenuationColor="#fff685"
              transmission={0.95}
              distortion={0.5}
              distortionScale={0.5}
              temporalDistortion={0.1}
            />
          </mesh>
          
          {/* Ears */}
          <group position={[0.8, 0.7, 0]}>
            <mesh position={[0, 0, 0.2]} rotation={[0.3, 0, 0.2]}>
              <coneGeometry args={[0.15, 0.4, 32]} />
              <meshPhongMaterial color="#ff1d58" />
            </mesh>
            <mesh position={[0, 0, -0.2]} rotation={[-0.3, 0, -0.2]}>
              <coneGeometry args={[0.15, 0.4, 32]} />
              <meshPhongMaterial color="#ff1d58" />
            </mesh>
          </group>
          
          {/* Tail */}
          <group position={[-0.8, 0.1, 0]}>
            <mesh rotation={[0, 0, Math.PI * 0.25]}>
              <cylinderGeometry args={[0.08, 0.04, 0.8, 32]} />
              <meshPhongMaterial color="#f75990" />
            </mesh>
          </group>
        </group>
      </mesh>
    </group>
  );
}