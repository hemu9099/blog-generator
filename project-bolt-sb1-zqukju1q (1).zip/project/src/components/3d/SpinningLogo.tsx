import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Center, TorusKnot } from '@react-three/drei';
import { Mesh } from 'three';

export function SpinningLogo() {
  const meshRef = useRef<Mesh>(null);

  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.5;
      meshRef.current.rotation.x += delta * 0.2;
    }
  });

  return (
    <Center>
      <mesh ref={meshRef}>
        <TorusKnot args={[1, 0.3, 128, 16]}>
          <meshNormalMaterial />
        </TorusKnot>
      </mesh>
    </Center>
  );
}