import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh } from 'three';
import { MeshTransmissionMaterial } from '@react-three/drei';

export function FloatingCrystal() {
  const meshRef = useRef<Mesh>(null);
  const time = useRef(0);

  useFrame((state, delta) => {
    if (meshRef.current) {
      time.current += delta;

      // Smooth floating animation
      meshRef.current.position.y = Math.sin(time.current * 0.8) * 0.2;
      
      // Gentle rotation
      meshRef.current.rotation.y += delta * 0.2;
      meshRef.current.rotation.x = Math.sin(time.current * 0.4) * 0.1;
      
      // Subtle breathing effect
      const scale = 1 + Math.sin(time.current * 1.5) * 0.03;
      meshRef.current.scale.setScalar(scale);
    }
  });

  return (
    <group>
      <mesh ref={meshRef}>
        {/* Main crystal body */}
        <group position={[0, 0, 0]}>
          <mesh>
            <octahedronGeometry args={[1, 2]} />
            <MeshTransmissionMaterial
              backside
              samples={6}
              thickness={0.4}
              roughness={0.1}
              color="#4f46e5"
              attenuationDistance={0.3}
              attenuationColor="#60a5fa"
              transmission={0.98}
              distortion={0.4}
              distortionScale={0.4}
              temporalDistortion={0.2}
              chromaticAberration={0.4}
              transparent={true}
              opacity={0.7}
            />
          </mesh>

          {/* Inner core */}
          <mesh scale={0.7}>
            <octahedronGeometry args={[1, 1]} />
            <meshPhongMaterial
              color="#818cf8"
              emissive="#4f46e5"
              emissiveIntensity={0.4}
              transparent={true}
              opacity={0.5}
            />
          </mesh>

          {/* Energy particles */}
          {[...Array(12)].map((_, i) => (
            <mesh
              key={i}
              position={[
                Math.sin((i / 12) * Math.PI * 2) * 0.7,
                Math.cos((i / 12) * Math.PI * 2) * 0.7,
                0
              ]}
              scale={0.08}
            >
              <sphereGeometry args={[1, 16, 16]} />
              <meshPhongMaterial
                color="#60a5fa"
                emissive="#4f46e5"
                emissiveIntensity={0.8}
                transparent={true}
                opacity={0.6}
              />
            </mesh>
          ))}
        </group>
      </mesh>

      {/* Ambient lighting */}
      <pointLight position={[2, 2, 2]} intensity={0.4} color="#4f46e5" />
      <pointLight position={[-2, -2, -2]} intensity={0.4} color="#60a5fa" />
    </group>
  );
}