import React, { useState, useEffect } from 'react';
import { PenLine, FileText, Clock, TrendingUp, Plus, Calendar, Star, Trash2, Edit2, AlertCircle, Loader2, X, Minimize2, Save } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useBlogStore } from '../store/blogStore';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { usePostsSubscription } from '../hooks/useSubscription';
import type { BlogPost } from '../types';

interface EditModalProps {
  post: BlogPost;
  onClose: () => void;
  onSave: (post: Partial<BlogPost>) => void;
}

function EditModal({ post, onClose, onSave }: EditModalProps) {
  const [title, setTitle] = useState(post.title);
  const [content, setContent] = useState(post.content);
  const [keywords, setKeywords] = useState(post.keywords);
  const [isPreview, setIsPreview] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      title,
      content,
      keywords,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-white">Edit Post</h3>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPreview(!isPreview)}
              className="btn btn-secondary"
            >
              {isPreview ? 'Edit' : 'Preview'}
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>

        {isPreview ? (
          <div className="prose prose-invert max-w-none">
            <h1 className="text-2xl font-bold mb-4">{title}</h1>
            <div className="flex gap-2 mb-4">
              {keywords.split(',').map((keyword, index) => (
                <span key={index} className="px-2 py-1 bg-gray-700 rounded-full text-sm">
                  {keyword.trim()}
                </span>
              ))}
            </div>
            <div className="whitespace-pre-wrap">{content}</div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="glass-input w-full"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Keywords</label>
              <input
                type="text"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                className="glass-input w-full"
                placeholder="Comma-separated keywords"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Content</label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="glass-input w-full h-96"
                required
              />
            </div>
            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="btn btn-secondary flex-1"
              >
                <X className="w-5 h-5" />
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary flex-1"
              >
                <Save className="w-5 h-5" />
                Save Changes
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

interface DeleteConfirmationProps {
  onConfirm: () => void;
  onCancel: () => void;
}

function DeleteConfirmation({ onConfirm, onCancel }: DeleteConfirmationProps) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center">
            <AlertCircle className="w-6 h-6 text-red-500" />
          </div>
          <div>
            <h3 className="text-xl font-semibold text-white">Delete Post</h3>
            <p className="text-gray-400">This action cannot be undone.</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="btn btn-secondary flex-1"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="btn bg-red-500 hover:bg-red-600 text-white flex-1"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

export function Dashboard() {
  const { user } = useAuthStore();
  const { posts, loading, error, getPosts, deletePost, updatePost, toggleStar } = useBlogStore();
  const navigate = useNavigate();
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
  const [deletingPost, setDeletingPost] = useState<string | null>(null);

  // Set up real-time subscription
  usePostsSubscription();

  // Initial posts fetch
  useEffect(() => {
    getPosts();
  }, [getPosts]);

  const publishedPosts = posts.filter(post => post.status === 'published');
  const scheduledPosts = posts.filter(post => post.status === 'scheduled');
  const draftPosts = posts.filter(post => post.status === 'draft');

  const stats = [
    { label: 'Total Posts', value: posts.length.toString(), icon: FileText, color: 'bg-blue-500' },
    { label: 'Drafts', value: draftPosts.length.toString(), icon: PenLine, color: 'bg-yellow-500' },
    { label: 'Published', value: publishedPosts.length.toString(), icon: Clock, color: 'bg-green-500' },
    { label: 'Scheduled', value: scheduledPosts.length.toString(), icon: Calendar, color: 'bg-purple-500' },
  ];

  const handleDelete = async (id: string) => {
    try {
      await deletePost(id);
      setDeletingPost(null);
    } catch (error) {
      console.error('Failed to delete post:', error);
    }
  };

  const handleEdit = async (post: BlogPost, updates: Partial<BlogPost>) => {
    try {
      await updatePost(post.id, updates);
      setEditingPost(null);
    } catch (error) {
      console.error('Failed to update post:', error);
    }
  };

  const handleStar = async (id: string) => {
    try {
      await toggleStar(id);
    } catch (error) {
      console.error('Failed to toggle star:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-500/10 border border-red-500 rounded-lg p-4 text-red-100">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Dashboard</h1>
          <p className="text-gray-400">Welcome back, {user?.username}</p>
        </div>
        <button
          onClick={() => navigate('/generate')}
          className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <Plus className="w-5 h-5 mr-2" />
          New Blog Post
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-gray-800 rounded-lg p-6 shadow-lg">
              <div className="flex items-center">
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-gray-400 text-sm">{stat.label}</p>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Published Posts */}
      <div className="bg-gray-800 rounded-lg shadow-lg">
        <div className="p-6">
          <h2 className="text-xl font-bold text-white mb-4">Published Posts</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-gray-400 border-b border-gray-700">
                  <th className="pb-3">Title</th>
                  <th className="pb-3">Keywords</th>
                  <th className="pb-3">Date</th>
                  <th className="pb-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {publishedPosts.map((post) => (
                  <tr key={post.id} className="border-b border-gray-700">
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleStar(post.id)}
                          className={`p-1 rounded-full transition-colors ${
                            post.isStarred ? 'text-yellow-400 hover:text-yellow-500' : 'text-gray-600 hover:text-gray-400'
                          }`}
                        >
                          <Star className="w-4 h-4 fill-current" />
                        </button>
                        <span className="text-white">{post.title}</span>
                      </div>
                    </td>
                    <td className="py-4 text-gray-400 max-w-xs truncate">{post.keywords}</td>
                    <td className="py-4 text-gray-400">
                      {format(new Date(post.createdAt), 'MMM dd, yyyy')}
                    </td>
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setEditingPost(post)}
                          className="p-2 text-blue-400 hover:text-blue-300 transition-colors rounded-lg hover:bg-blue-500/10"
                          title="Edit post"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeletingPost(post.id)}
                          className="p-2 text-red-400 hover:text-red-300 transition-colors rounded-lg hover:bg-red-500/10"
                          title="Delete post"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {publishedPosts.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-4 text-center text-gray-400">
                      No published posts yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Scheduled Posts */}
      <div className="bg-gray-800 rounded-lg shadow-lg">
        <div className="p-6">
          <h2 className="text-xl font-bold text-white mb-4">Scheduled Posts</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-gray-400 border-b border-gray-700">
                  <th className="pb-3">Title</th>
                  <th className="pb-3">Keywords</th>
                  <th className="pb-3">Scheduled For</th>
                  <th className="pb-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {scheduledPosts.map((post) => (
                  <tr key={post.id} className="border-b border-gray-700">
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleStar(post.id)}
                          className={`p-1 rounded-full transition-colors ${
                            post.isStarred ? 'text-yellow-400 hover:text-yellow-500' : 'text-gray-600 hover:text-gray-400'
                          }`}
                        >
                          <Star className="w-4 h-4 fill-current" />
                        </button>
                        <span className="text-white">{post.title}</span>
                      </div>
                    </td>
                    <td className="py-4 text-gray-400 max-w-xs truncate">{post.keywords}</td>
                    <td className="py-4 text-gray-400">
                      {post.scheduledFor && format(new Date(post.scheduledFor), 'MMM dd, yyyy HH:mm')}
                    </td>
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setEditingPost(post)}
                          className="p-2 text-blue-400 hover:text-blue-300 transition-colors rounded-lg hover:bg-blue-500/10"
                          title="Edit post"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeletingPost(post.id)}
                          className="p-2 text-red-400 hover:text-red-300 transition-colors rounded-lg hover:bg-red-500/10"
                          title="Delete post"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {scheduledPosts.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-4 text-center text-gray-400">
                      No scheduled posts yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Edit Modal */}
      {editingPost && (
        <EditModal
          post={editingPost}
          onClose={() => setEditingPost(null)}
          onSave={(updates) => handleEdit(editingPost, updates)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deletingPost && (
        <DeleteConfirmation
          onConfirm={() => handleDelete(deletingPost)}
          onCancel={() => setDeletingPost(null)}
        />
      )}
    </div>
  );
}