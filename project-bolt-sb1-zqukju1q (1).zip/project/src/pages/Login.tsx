import React, { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Canvas } from '@react-three/fiber';
import { SpinningLogo } from '../components/3d/SpinningLogo';
import { useAuthStore } from '../store/authStore';

export function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { user, login, signup } = useAuthStore();
  const navigate = useNavigate();

  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    try {
      if (isLogin) {
        await login(email, password);
      } else {
        if (!username.trim()) {
          throw new Error('Username is required');
        }
        if (username.length < 3) {
          throw new Error('Username must be at least 3 characters long');
        }
        await signup(email, username, password);
      }
      
      navigate('/dashboard', { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setPassword('');
    }
  };

  const toggleMode = () => {
    setIsLogin(!isLogin);
    setEmail('');
    setUsername('');
    setPassword('');
    setError('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-accent-900 via-accent-800 to-accent-900 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Welcome to Deepthi's Blog Generator
          </h1>
          <p className="text-mountain-300 text-lg">
            Create engaging content with the power of AI
          </p>
        </div>
        
        <div className="h-48 w-full">
          <Canvas camera={{ position: [0, 0, 5] }}>
            <ambientLight intensity={0.5} />
            <pointLight position={[10, 10, 10]} />
            <SpinningLogo />
          </Canvas>
        </div>
        
        <div className="glass-card p-8">
          <h2 className="text-center text-3xl font-extrabold gradient-text mb-6">
            {isLogin ? 'Sign in to your account' : 'Create your account'}
          </h2>
          
          {error && (
            <div className="mt-4 p-3 bg-red-500/10 border border-red-500/50 text-red-400 text-center rounded-lg">
              {error}
            </div>
          )}
          
          <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
            <div className="rounded-md shadow-sm space-y-4">
              <div>
                <label htmlFor="email" className="sr-only">
                  Email address
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="glass-input w-full"
                  placeholder="Email address"
                />
              </div>
              {!isLogin && (
                <div>
                  <label htmlFor="username" className="sr-only">
                    Username
                  </label>
                  <input
                    id="username"
                    name="username"
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="glass-input w-full"
                    placeholder="Username"
                  />
                </div>
              )}
              <div>
                <label htmlFor="password" className="sr-only">
                  Password
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="glass-input w-full"
                  placeholder="Password"
                />
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary w-full"
            >
              {isLogin ? 'Sign in' : 'Sign up'}
            </button>
          </form>
          
          <div className="mt-4 text-center">
            <button
              onClick={toggleMode}
              className="text-primary-400 hover:text-primary-300 text-sm font-medium transition-colors"
            >
              {isLogin ? 'Need an account? Sign up' : 'Already have an account? Sign in'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}