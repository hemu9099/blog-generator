import React, { useEffect } from 'react';
import { useAuthStore } from '../store/authStore';
import { useAnalyticsStore } from '../store/analyticsStore';
import { Loader2, Calendar, BookOpen, Clock } from 'lucide-react';
import { Line, Bar } from 'react-chartjs-2';
import { format } from 'date-fns';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export function Analytics() {
  const { user } = useAuthStore();
  const { data, loading, error, fetchAnalytics } = useAnalyticsStore();

  useEffect(() => {
    if (user) {
      fetchAnalytics(user.id);
    }
  }, [user, fetchAnalytics]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-500/10 border border-red-500 rounded-lg p-4 text-red-100">
        {error}
      </div>
    );
  }

  if (!data) {
    return null;
  }

  const viewsChartData = {
    labels: data.viewsByDate.map(item => format(new Date(item.date), 'MMM dd')),
    datasets: [
      {
        label: 'Views',
        data: data.viewsByDate.map(item => item.views),
        borderColor: 'rgb(99, 102, 241)',
        backgroundColor: 'rgba(99, 102, 241, 0.5)',
        tension: 0.4,
      },
    ],
  };

  const topPostsChartData = {
    labels: data.topPosts.map(post => post.title),
    datasets: [
      {
        label: 'Views',
        data: data.topPosts.map(post => post.views),
        backgroundColor: 'rgba(99, 102, 241, 0.5)',
        borderColor: 'rgb(99, 102, 241)',
      },
    ],
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">Analytics Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-300">Total Views</h3>
          <p className="text-3xl font-bold text-white mt-2">{data.totalViews}</p>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-300">Avg. Read Time</h3>
          <p className="text-3xl font-bold text-white mt-2">
            {Math.round(data.avgReadTime)} min
          </p>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-medium text-gray-300">Published Posts</h3>
          </div>
          <p className="text-3xl font-bold text-white mt-2">
            {data.publishedPosts}
          </p>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-medium text-gray-300">Upcoming Posts</h3>
          </div>
          <p className="text-3xl font-bold text-white mt-2">
            {data.upcomingPosts.length}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-300 mb-4">Views Over Time</h3>
          <div className="h-[300px]">
            <Line
              data={viewsChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    beginAtZero: true,
                    ticks: { color: '#9CA3AF' },
                    grid: { color: '#374151' },
                  },
                  x: {
                    ticks: { color: '#9CA3AF' },
                    grid: { color: '#374151' },
                  },
                },
                plugins: {
                  legend: {
                    labels: { color: '#9CA3AF' },
                  },
                },
              }}
            />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-300 mb-4">Top Posts</h3>
          <div className="h-[300px]">
            <Bar
              data={topPostsChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    beginAtZero: true,
                    ticks: { color: '#9CA3AF' },
                    grid: { color: '#374151' },
                  },
                  x: {
                    ticks: { color: '#9CA3AF' },
                    grid: { color: '#374151' },
                  },
                },
                plugins: {
                  legend: {
                    labels: { color: '#9CA3AF' },
                  },
                },
              }}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-300 mb-4">Top Performing Posts</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-gray-400 border-b border-gray-700">
                  <th className="pb-3">Title</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3">Views</th>
                  <th className="pb-3">Published</th>
                </tr>
              </thead>
              <tbody>
                {data.topPosts.map((post) => (
                  <tr key={post.id} className="border-b border-gray-700">
                    <td className="py-4 text-white">{post.title}</td>
                    <td className="py-4">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        post.status === 'published' 
                          ? 'bg-green-500/20 text-green-400'
                          : 'bg-blue-500/20 text-blue-400'
                      }`}>
                        {post.status}
                      </span>
                    </td>
                    <td className="py-4 text-gray-400">{post.views}</td>
                    <td className="py-4 text-gray-400">
                      {format(new Date(post.publishedAt), 'MMM dd, yyyy')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-300 mb-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Upcoming Posts
            </div>
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-gray-400 border-b border-gray-700">
                  <th className="pb-3">Title</th>
                  <th className="pb-3">Scheduled For</th>
                  <th className="pb-3">Keywords</th>
                </tr>
              </thead>
              <tbody>
                {data.upcomingPosts.map((post) => (
                  <tr key={post.id} className="border-b border-gray-700">
                    <td className="py-4 text-white">{post.title}</td>
                    <td className="py-4 text-gray-400">
                      {format(new Date(post.scheduledFor), 'MMM dd, yyyy HH:mm')}
                    </td>
                    <td className="py-4">
                      <div className="flex flex-wrap gap-2">
                        {post.keywords.split(',').map((keyword, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-gray-700 rounded-full text-xs text-gray-300"
                          >
                            {keyword.trim()}
                          </span>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
                {data.upcomingPosts.length === 0 && (
                  <tr>
                    <td colSpan={3} className="py-4 text-center text-gray-400">
                      No upcoming posts scheduled
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}