import React, { useState } from 'react';
import { Wand2, Sparkles, Clock, Calendar, Send, Edit, CalendarClock, X, Tag } from 'lucide-react';
import { useBlogStore } from '../store/blogStore';
import { useAuthStore } from '../store/authStore';
import { useNavigate } from 'react-router-dom';
import { CohereClient } from 'cohere-ai';

const cohere = new CohereClient({
  token: import.meta.env.VITE_COHERE_API_KEY,
});

interface GeneratorForm {
  title: string;
  description: string;
}

interface GeneratedContent {
  title: string;
  content: string;
  keywords: string[];
  outline: string[];
}

interface ScheduleModalProps {
  onClose: () => void;
  onSchedule: (date: string) => void;
}

function ScheduleModal({ onClose, onSchedule }: ScheduleModalProps) {
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dateTime = new Date(`${selectedDate}T${selectedTime}`).toISOString();
    onSchedule(dateTime);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-accent-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-white">Schedule Post</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Date</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="glass-input w-full"
              min={new Date().toISOString().split('T')[0]}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Time</label>
            <input
              type="time"
              value={selectedTime}
              onChange={(e) => setSelectedTime(e.target.value)}
              className="glass-input w-full"
              required
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="btn btn-secondary flex-1"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary flex-1"
            >
              Schedule
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export function Generator() {
  const { user } = useAuthStore();
  const { addPost } = useBlogStore();
  const navigate = useNavigate();
  const [generating, setGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState('');
  const [showScheduleModal, setShowScheduleModal] = useState(false);

  const [form, setForm] = useState<GeneratorForm>({
    title: '',
    description: '',
  });

  const generateWithCohere = async (): Promise<GeneratedContent> => {
    // Generate outline
    const outlinePrompt = `Create a detailed outline for a professional blog post about "${form.description}" with the title "${form.title}".
                          The outline should include:
                          1. Introduction
                          2. 3-4 main sections with clear subpoints
                          3. Conclusion
                          Format as a bullet-point list.`;

    const outlineResponse = await cohere.generate({
      prompt: outlinePrompt,
      maxTokens: 500,
      temperature: 0.7,
      model: 'command',
    });

    const outline = outlineResponse.generations[0].text.split('\n').filter(Boolean);

    // Generate content
    const contentPrompt = `Write a professional, engaging, and well-researched blog post following this outline:
                          ${outline.join('\n')}
                          
                          Requirements:
                          - Write in a professional yet engaging tone
                          - Include relevant examples and data points
                          - Use proper formatting with headers (use markdown)
                          - Ensure smooth transitions between sections
                          - Add a compelling introduction and conclusion
                          - Aim for clarity and actionable insights
                          - Include citations or references where appropriate`;

    const contentResponse = await cohere.generate({
      prompt: contentPrompt,
      maxTokens: 1000,
      temperature: 0.7,
      model: 'command',
    });

    const content = contentResponse.generations[0].text;

    // Generate keywords
    const keywordPrompt = `Analyze this blog post and generate 5-7 highly relevant SEO keywords:
                          Title: "${form.title}"
                          Content: "${content}"
                          
                          Requirements:
                          - Include both short and long-tail keywords
                          - Focus on relevance and search intent
                          - Consider current SEO best practices
                          - Include industry-specific terms where appropriate
                          - Ensure keywords are naturally used in the content`;

    const keywordResponse = await cohere.generate({
      prompt: keywordPrompt,
      maxTokens: 200,
      temperature: 0.6,
      model: 'command',
    });

    const keywords = keywordResponse.generations[0].text
      .split('\n')
      .filter(Boolean)
      .map(k => k.replace(/^[-\d.*]\s*/, '').trim());

    return {
      title: form.title,
      content,
      keywords,
      outline
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerating(true);
    setError(null);
    
    try {
      const content = await generateWithCohere();
      setGeneratedContent(content);

      // Save as draft
      await addPost({
        title: content.title,
        content: content.content,
        keywords: content.keywords.join(', '),
        status: 'draft',
        authorId: user!.id
      });
    } catch (error) {
      console.error('Generation failed:', error);
      setError('Failed to generate content. Please try again.');
    } finally {
      setGenerating(false);
    }
  };

  const handlePublish = async () => {
    if (!generatedContent) return;
    
    try {
      await addPost({
        title: generatedContent.title,
        content: isEditing ? editedContent : generatedContent.content,
        keywords: generatedContent.keywords.join(', '),
        status: 'published',
        authorId: user!.id
      });
      navigate('/dashboard');
    } catch (error) {
      setError('Failed to publish post');
    }
  };

  const handleSchedule = async (scheduledDate: string) => {
    if (!generatedContent) return;
    
    try {
      await addPost({
        title: generatedContent.title,
        content: isEditing ? editedContent : generatedContent.content,
        keywords: generatedContent.keywords.join(', '),
        status: 'scheduled',
        scheduledFor: scheduledDate,
        authorId: user!.id
      });
      navigate('/dashboard');
    } catch (error) {
      setError('Failed to schedule post');
    }
  };

  const toggleEdit = () => {
    if (!isEditing && generatedContent) {
      setEditedContent(generatedContent.content);
    }
    setIsEditing(!isEditing);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold gradient-text mb-4">Professional Blog Generator</h1>
        <p className="text-lg text-mountain-300">
          Create well-structured, engaging content powered by advanced AI
        </p>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-500/10 border border-red-500 rounded-lg text-red-400">
          {error}
        </div>
      )}
      
      <div className="glass-card p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-crown-300 mb-2">
              Blog Title
            </label>
            <input
              type="text"
              id="title"
              name="title"
              value={form.title}
              onChange={handleInputChange}
              className="glass-input w-full"
              placeholder="Enter a compelling title for your blog post"
              required
            />
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-crown-300 mb-2">
              Topic Description
            </label>
            <textarea
              id="description"
              name="description"
              value={form.description}
              onChange={handleInputChange}
              className="glass-input w-full h-32 resize-none"
              placeholder="Describe your topic in detail, including key points you'd like to cover..."
              required
            />
          </div>

          <div className="flex items-center gap-4 pt-4">
            <button
              type="submit"
              disabled={generating}
              className="btn btn-primary flex-1"
            >
              {generating ? (
                <>
                  <Sparkles className="w-5 h-5 animate-spin" />
                  Generating Professional Content...
                </>
              ) : (
                <>
                  <Wand2 className="w-5 h-5" />
                  Generate Blog Post
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Preview section */}
      {generatedContent && (
        <div className="mt-8 space-y-6">
          {/* Keywords section with improved styling */}
          <div className="glass-card p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-primary-500/20 flex items-center justify-center">
                <Tag className="w-5 h-5 text-primary-500" />
              </div>
              <h2 className="text-2xl font-bold text-white">SEO Keywords</h2>
            </div>
            <div className="flex flex-wrap gap-3">
              {generatedContent.keywords.map((keyword, index) => (
                <div
                  key={index}
                  className="px-4 py-2 bg-gradient-to-br from-primary-500/10 to-primary-600/10 
                           border border-primary-500/20 rounded-lg text-primary-300 
                           shadow-sm hover:shadow-primary-500/10 transition-all duration-300
                           hover:border-primary-500/30"
                >
                  <span className="text-sm font-medium">{keyword}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Content Preview */}
          <div className="glass-card p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-accent-500/20 flex items-center justify-center">
                <Edit className="w-5 h-5 text-accent-500" />
              </div>
              <h2 className="text-2xl font-bold text-white">Generated Content</h2>
            </div>
            <div className="prose prose-invert max-w-none">
              <h3 className="text-xl font-semibold mb-4">{generatedContent.title}</h3>
              {isEditing ? (
                <textarea
                  value={editedContent}
                  onChange={(e) => setEditedContent(e.target.value)}
                  className="glass-input w-full h-96 font-mono text-sm"
                />
              ) : (
                <div className="whitespace-pre-wrap">{generatedContent.content}</div>
              )}
            </div>
            
            {/* Post management buttons */}
            <div className="flex gap-4 mt-6">
              <button
                onClick={handlePublish}
                className="btn btn-primary flex-1"
              >
                <Send className="w-5 h-5" />
                Publish Post
              </button>
              <button
                onClick={() => setShowScheduleModal(true)}
                className="btn btn-secondary flex-1"
              >
                <CalendarClock className="w-5 h-5" />
                Schedule Post
              </button>
              <button
                onClick={toggleEdit}
                className="btn btn-secondary flex-1"
              >
                <Edit className="w-5 h-5" />
                {isEditing ? 'Save Changes' : 'Edit Content'}
              </button>
            </div>
          </div>

          {/* Outline Preview */}
          <div className="glass-card p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-crown-500/20 flex items-center justify-center">
                <Clock className="w-5 h-5 text-crown-500" />
              </div>
              <h2 className="text-2xl font-bold text-white">Content Outline</h2>
            </div>
            <ul className="space-y-2 text-mountain-300">
              {generatedContent.outline.map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-primary-500">•</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Features section */}
      <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6">
          <div className="w-12 h-12 rounded-full bg-primary-500/20 flex items-center justify-center mb-4">
            <Wand2 className="w-6 h-6 text-primary-500" />
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">Professional Structure</h3>
          <p className="text-mountain-300">
            AI generates well-organized content with clear sections and smooth transitions.
          </p>
        </div>

        <div className="glass-card p-6">
          <div className="w-12 h-12 rounded-full bg-accent-500/20 flex items-center justify-center mb-4">
            <Clock className="w-6 h-6 text-accent-500" />
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">Research-Backed</h3>
          <p className="text-mountain-300">
            Content includes relevant examples, data points, and industry insights.
          </p>
        </div>

        <div className="glass-card p-6">
          <div className="w-12 h-12 rounded-full bg-crown-500/20 flex items-center justify-center mb-4">
            <Calendar className="w-6 h-6 text-crown-500" />
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">SEO Optimized</h3>
          <p className="text-mountain-300">
            Strategic keywords and structure for maximum search visibility.
          </p>
        </div>
      </div>

      {/* Schedule Modal */}
      {showScheduleModal && (
        <ScheduleModal
          onClose={() => setShowScheduleModal(false)}
          onSchedule={handleSchedule}
        />
      )}

      {/* Loading overlay */}
      {generating && (
        <div className="fixed inset-0 bg-accent-900/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-accent-800/90 backdrop-blur-sm rounded-xl p-8 shadow-xl border border-accent-700/50">
            <div className="text-center">
              <Sparkles className="w-8 h-8 text-primary-500 animate-spin mx-auto mb-4" />
              <p className="text-lg text-white">Generating content...</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}