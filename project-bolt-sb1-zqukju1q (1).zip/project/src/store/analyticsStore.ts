import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { AnalyticsData, PostView, PostInteraction } from '../types';

interface AnalyticsState {
  data: AnalyticsData | null;
  loading: boolean;
  error: string | null;
  fetchAnalytics: (userId: string) => Promise<void>;
  trackView: (postId: string, source?: string) => Promise<void>;
  trackInteraction: (postId: string, type: 'read_time' | 'scroll_depth', value: number) => Promise<void>;
}

export const useAnalyticsStore = create<AnalyticsState>((set) => ({
  data: null,
  loading: false,
  error: null,
  fetchAnalytics: async (userId: string) => {
    try {
      set({ loading: true, error: null });

      // Fetch total views
      const { data: viewsData, error: viewsError } = await supabase
        .from('post_views')
        .select('post_id')
        .eq('viewer_id', userId);

      if (viewsError) throw viewsError;

      // Fetch average read time
      const { data: readTimeData, error: readTimeError } = await supabase
        .from('post_interactions')
        .select('value')
        .eq('user_id', userId)
        .eq('type', 'read_time');

      if (readTimeError) throw readTimeError;

      // Fetch views by date
      const { data: viewsByDateData, error: viewsByDateError } = await supabase
        .from('post_views')
        .select('viewed_at')
        .eq('viewer_id', userId)
        .order('viewed_at', { ascending: true });

      if (viewsByDateError) throw viewsByDateError;

      // Fetch all posts (both published and scheduled)
      const { data: allPostsData, error: allPostsError } = await supabase
        .from('posts')
        .select(`
          id,
          title,
          status,
          view_count,
          avg_read_time,
          scheduled_for,
          keywords,
          created_at
        `)
        .order('view_count', { ascending: false });

      if (allPostsError) throw allPostsError;

      // Process posts data
      const now = new Date();
      const publishedPosts = allPostsData.filter(post => post.status === 'published');
      const upcomingPosts = allPostsData.filter(post => 
        post.status === 'scheduled' && 
        new Date(post.scheduled_for) > now
      );

      // Get top performing posts (combining both published and past scheduled posts)
      const topPosts = allPostsData
        .filter(post => post.status === 'published' || 
          (post.status === 'scheduled' && new Date(post.scheduled_for) <= now))
        .sort((a, b) => b.view_count - a.view_count)
        .slice(0, 5);

      // Process the data
      const viewsByDate = viewsByDateData.reduce((acc: { [key: string]: number }, view) => {
        const date = new Date(view.viewed_at).toISOString().split('T')[0];
        acc[date] = (acc[date] || 0) + 1;
        return acc;
      }, {});

      const analyticsData: AnalyticsData = {
        totalViews: viewsData.length,
        avgReadTime: readTimeData.reduce((acc, curr) => acc + curr.value, 0) / readTimeData.length || 0,
        totalPosts: allPostsData.length,
        publishedPosts: publishedPosts.length,
        viewsByDate: Object.entries(viewsByDate).map(([date, views]) => ({ date, views })),
        topPosts: topPosts.map(post => ({
          id: post.id,
          title: post.title,
          views: post.view_count,
          avgReadTime: post.avg_read_time,
          status: post.status,
          publishedAt: post.status === 'published' ? post.created_at : post.scheduled_for,
        })),
        upcomingPosts: upcomingPosts.map(post => ({
          id: post.id,
          title: post.title,
          scheduledFor: post.scheduled_for,
          keywords: post.keywords || '',
        })),
      };

      set({ data: analyticsData });
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'Failed to fetch analytics' });
    } finally {
      set({ loading: false });
    }
  },
  trackView: async (postId: string, source = 'direct') => {
    try {
      const { error } = await supabase
        .from('post_views')
        .insert([
          {
            post_id: postId,
            viewer_id: (await supabase.auth.getUser()).data.user?.id,
            source,
          },
        ]);

      if (error) throw error;
    } catch (error) {
      console.error('Failed to track view:', error);
    }
  },
  trackInteraction: async (postId: string, type: 'read_time' | 'scroll_depth', value: number) => {
    try {
      const { error } = await supabase
        .from('post_interactions')
        .insert([
          {
            post_id: postId,
            user_id: (await supabase.auth.getUser()).data.user?.id,
            type,
            value,
          },
        ]);

      if (error) throw error;
    } catch (error) {
      console.error('Failed to track interaction:', error);
    }
  },
}));