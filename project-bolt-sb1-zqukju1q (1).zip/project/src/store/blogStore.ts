import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { BlogPost } from '../types';

interface BlogState {
  posts: BlogPost[];
  loading: boolean;
  error: string | null;
  addPost: (post: Omit<BlogPost, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updatePost: (id: string, post: Partial<BlogPost>) => Promise<void>;
  deletePost: (id: string) => Promise<void>;
  getPosts: () => Promise<void>;
  toggleStar: (id: string) => Promise<void>;
}

export const useBlogStore = create<BlogState>((set, get) => ({
  posts: [],
  loading: false,
  error: null,
  addPost: async (post) => {
    try {
      set({ loading: true, error: null });
      const { data, error } = await supabase
        .from('posts')
        .insert([{
          title: post.title,
          content: post.content,
          keywords: post.keywords,
          status: post.status,
          scheduled_for: post.scheduledFor,
          author_id: post.authorId,
        }])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const newPost: BlogPost = {
          id: data.id,
          title: data.title,
          content: data.content,
          keywords: data.keywords,
          status: data.status,
          scheduledFor: data.scheduled_for,
          authorId: data.author_id,
          createdAt: data.created_at,
          updatedAt: data.updated_at,
          isStarred: data.is_starred,
          viewCount: data.view_count,
          avgReadTime: data.avg_read_time,
        };

        set((state) => ({ posts: [...state.posts, newPost] }));
      }
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'Failed to add post' });
      throw error;
    } finally {
      set({ loading: false });
    }
  },
  updatePost: async (id, updatedPost) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('posts')
        .update({
          title: updatedPost.title,
          content: updatedPost.content,
          keywords: updatedPost.keywords,
          status: updatedPost.status,
          scheduled_for: updatedPost.scheduledFor,
          is_starred: updatedPost.isStarred,
        })
        .eq('id', id);

      if (error) throw error;

      set((state) => ({
        posts: state.posts.map((post) =>
          post.id === id
            ? { ...post, ...updatedPost, updatedAt: new Date().toISOString() }
            : post
        ),
      }));
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'Failed to update post' });
      throw error;
    } finally {
      set({ loading: false });
    }
  },
  deletePost: async (id) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('posts')
        .delete()
        .eq('id', id);

      if (error) throw error;

      set((state) => ({
        posts: state.posts.filter((post) => post.id !== id),
      }));
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'Failed to delete post' });
      throw error;
    } finally {
      set({ loading: false });
    }
  },
  getPosts: async () => {
    try {
      set({ loading: true, error: null });
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      if (data) {
        const posts: BlogPost[] = data.map((post) => ({
          id: post.id,
          title: post.title,
          content: post.content,
          keywords: post.keywords,
          status: post.status,
          scheduledFor: post.scheduled_for,
          authorId: post.author_id,
          createdAt: post.created_at,
          updatedAt: post.updated_at,
          isStarred: post.is_starred,
          viewCount: post.view_count,
          avgReadTime: post.avg_read_time,
        }));

        set({ posts });
      }
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'Failed to fetch posts' });
      throw error;
    } finally {
      set({ loading: false });
    }
  },
  toggleStar: async (id) => {
    try {
      const post = get().posts.find(p => p.id === id);
      if (!post) return;

      const newStarredState = !post.isStarred;
      
      const { error } = await supabase
        .from('posts')
        .update({ is_starred: newStarredState })
        .eq('id', id);

      if (error) throw error;

      set((state) => ({
        posts: state.posts.map((post) =>
          post.id === id
            ? { ...post, isStarred: newStarredState }
            : post
        ),
      }));
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'Failed to update star status' });
      throw error;
    }
  },
}));