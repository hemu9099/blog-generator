import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { AuthState, User } from '../types';

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  login: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      throw new Error(error.message);
    }

    if (data.user) {
      try {
        // Try to fetch existing profile
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', data.user.id)
          .single();

        if (profileError && profileError.code === 'PGRST116') {
          // Profile doesn't exist, create one
          const defaultUsername = email.split('@')[0];
          const { data: newProfile, error: createError } = await supabase
            .from('profiles')
            .insert([
              {
                id: data.user.id,
                username: defaultUsername,
                role: 'user',
              },
            ])
            .select()
            .single();

          if (createError) {
            throw new Error('Failed to create user profile');
          }

          const user: User = {
            id: data.user.id,
            email: data.user.email!,
            username: newProfile.username,
            role: newProfile.role,
          };

          set({ user });
          return;
        } else if (profileError) {
          throw profileError;
        }

        const user: User = {
          id: data.user.id,
          email: data.user.email!,
          username: profile.username,
          role: profile.role,
        };

        set({ user });
      } catch (err) {
        throw new Error('Failed to fetch or create user profile');
      }
    }
  },
  signup: async (email: string, username: string, password: string) => {
    // First check if user exists
    const { data: existingUser } = await supabase
      .from('profiles')
      .select('username')
      .eq('username', username)
      .single();

    if (existingUser) {
      throw new Error('Username is already taken');
    }

    // Attempt to sign up the user
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) {
      if (error.message.includes('already registered')) {
        throw new Error('This email is already registered. Please sign in instead.');
      }
      throw new Error(error.message);
    }

    if (!data.user) {
      throw new Error('Signup failed - no user data returned');
    }

    try {
      // Create profile with transaction-like behavior
      const { error: profileError } = await supabase
        .from('profiles')
        .insert([
          {
            id: data.user.id,
            username,
            role: 'user',
          },
        ])
        .select()
        .single();

      if (profileError) {
        // If profile creation fails, we should clean up the auth user
        await supabase.auth.signOut();
        throw new Error('Failed to create user profile. Please try again.');
      }

      const user: User = {
        id: data.user.id,
        email: data.user.email!,
        username,
        role: 'user',
      };

      set({ user });
    } catch (err) {
      // Clean up auth user if profile creation fails
      await supabase.auth.signOut();
      throw err;
    }
  },
  logout: async () => {
    await supabase.auth.signOut();
    set({ user: null });
  },
}));