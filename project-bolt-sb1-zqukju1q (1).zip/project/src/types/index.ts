export interface User {
  id: string;
  email: string;
  username: string;
  role: 'admin' | 'user';
}

export interface BlogPost {
  id: string;
  title: string;
  content: string;
  keywords: string;
  status: 'draft' | 'published' | 'scheduled';
  scheduledFor?: string;
  createdAt: string;
  updatedAt: string;
  authorId: string;
  viewCount: number;
  avgReadTime: number;
  isStarred: boolean;
}

export interface PostView {
  id: string;
  postId: string;
  viewerId: string;
  viewedAt: string;
  source: string;
}

export interface PostInteraction {
  id: string;
  postId: string;
  userId: string;
  type: 'read_time' | 'scroll_depth';
  value: number;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, username: string, password: string) => Promise<void>;
  logout: () => void;
}

export interface AnalyticsData {
  totalViews: number;
  avgReadTime: number;
  totalPosts: number;
  publishedPosts: number;
  viewsByDate: {
    date: string;
    views: number;
  }[];
  topPosts: {
    id: string;
    title: string;
    views: number;
    avgReadTime: number;
    status: 'published' | 'scheduled';
    publishedAt: string;
  }[];
  upcomingPosts: {
    id: string;
    title: string;
    scheduledFor: string;
    keywords: string;
  }[];
}