export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          username: string
          role: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          username: string
          role?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          username?: string
          role?: string
          created_at?: string
          updated_at?: string
        }
      }
      posts: {
        Row: {
          id: string
          title: string
          content: string
          keywords: string | null
          status: string
          scheduled_for: string | null
          author_id: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          content: string
          keywords?: string | null
          status?: string
          scheduled_for?: string | null
          author_id: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          content?: string
          keywords?: string | null
          status?: string
          scheduled_for?: string | null
          author_id?: string
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}