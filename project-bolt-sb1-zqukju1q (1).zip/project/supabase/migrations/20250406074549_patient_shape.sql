/*
  # Add is_starred column to posts table

  1. Changes
    - Add is_starred boolean column to posts table with default value false
*/

ALTER TABLE posts ADD COLUMN IF NOT EXISTS is_starred boolean DEFAULT false;