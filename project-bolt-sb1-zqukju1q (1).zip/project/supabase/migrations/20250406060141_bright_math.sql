/*
  # Add Analytics Tables

  1. New Tables
    - `post_views`
      - `id` (uuid, primary key)
      - `post_id` (uuid, references posts)
      - `viewer_id` (uuid, references profiles)
      - `viewed_at` (timestamp)
      - `view_date` (date) - extracted date for uniqueness constraint
      - `source` (text) - where the view came from
    
    - `post_interactions`
      - `id` (uuid, primary key)
      - `post_id` (uuid, references posts)
      - `user_id` (uuid, references profiles)
      - `type` (text) - type of interaction (read_time, scroll_depth)
      - `value` (integer) - value of the interaction
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create post_views table
CREATE TABLE IF NOT EXISTS post_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES posts(id) ON DELETE CASCADE NOT NULL,
  viewer_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  viewed_at timestamptz DEFAULT now(),
  view_date date DEFAULT CURRENT_DATE,
  source text DEFAULT 'direct',
  UNIQUE(post_id, viewer_id, view_date)
);

-- Create post_interactions table
CREATE TABLE IF NOT EXISTS post_interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES posts(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL,
  value integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE post_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_interactions ENABLE ROW LEVEL SECURITY;

-- Post views policies
CREATE POLICY "Users can view their own views"
  ON post_views
  FOR SELECT
  TO authenticated
  USING (viewer_id = auth.uid());

CREATE POLICY "Users can create views"
  ON post_views
  FOR INSERT
  TO authenticated
  WITH CHECK (viewer_id = auth.uid());

-- Post interactions policies
CREATE POLICY "Users can view their own interactions"
  ON post_interactions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create interactions"
  ON post_interactions
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Add view count to posts table
ALTER TABLE posts ADD COLUMN IF NOT EXISTS view_count integer DEFAULT 0;
ALTER TABLE posts ADD COLUMN IF NOT EXISTS avg_read_time integer DEFAULT 0;