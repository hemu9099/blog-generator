/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fff1f4',
          100: '#ffe4ea',
          200: '#ffc8d6',
          300: '#ff9cb6',
          400: '#ff5c8a',
          500: '#ff1d58', // Yass Queen
          600: '#f75990', // Sister Sister
          700: '#cc0d3d',
          800: '#a70b32',
          900: '#8a0a2a',
        },
        accent: {
          50: '#e6f9ff',
          100: '#ccf3ff',
          200: '#99e7ff',
          300: '#66dbff',
          400: '#33cfff',
          500: '#00DDFF', // Blue Light
          600: '#0049B7', // Brutal Blue
          700: '#003384',
          800: '#002251',
          900: '#00111e',
        },
        crown: {
          50: '#fffff2',
          100: '#ffffe5',
          200: '#ffffc8',
          300: '#ffffab',
          400: '#ffff8e',
          500: '#fff685', // Crown Yellow
          600: '#ccc56a',
          700: '#999450',
          800: '#666235',
          900: '#33311b',
        },
        mountain: {
          50: '#f5f7fa',
          100: '#eaedf4',
          200: '#d5dce8',
          300: '#a3b1c6', // Mountain Mist
          400: '#8291a9',
          500: '#63728c',
          600: '#4c5a73',
          700: '#3d4a61',
          800: '#2d3748',
          900: '#1a212f',
        }
      },
      animation: {
        'spin-slow': 'spin 3s linear infinite',
        'shimmer': 'shimmer 1.5s infinite',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'run': 'run 1s infinite alternate ease-in-out',
        'bounce-slow': 'bounce 2s infinite ease-in-out',
      },
      keyframes: {
        shimmer: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' }
        },
        run: {
          '0%': { transform: 'translateX(-20%) scaleX(1)' },
          '25%': { transform: 'translateX(-10%) scaleX(0.9) scaleY(1.1)' },
          '50%': { transform: 'translateX(0%) scaleX(1)' },
          '75%': { transform: 'translateX(10%) scaleX(0.9) scaleY(1.1)' },
          '100%': { transform: 'translateX(20%) scaleX(1)' }
        },
        bounce: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10%)' }
        }
      },
      boxShadow: {
        'inner-lg': 'inset 0 2px 4px 0 rgb(0 0 0 / 0.15)',
        'glow': '0 0 15px -3px rgb(255, 29, 88 / 0.3)',
        'glow-lg': '0 0 25px -5px rgb(255, 29, 88 / 0.3)',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(var(--tw-gradient-stops))',
        'gradient-shine': 'linear-gradient(45deg, transparent 25%, rgba(255,255,255,0.1) 25%, rgba(255,255,255,0.1) 50%, transparent 50%, transparent 75%, rgba(255,255,255,0.1) 75%, rgba(255,255,255,0.1))',
      }
    },
  },
  plugins: [],
};